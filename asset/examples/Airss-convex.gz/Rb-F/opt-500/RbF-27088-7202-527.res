TITL RbF-27088-7202-527 499.9933 18.074828 -1.29751297E+003 0 0 2 (Fm-3m) n - 1
REM
REM Run started: Fri, 03 Jul 2020 19:03:29 +0800 in /data4/home/cuit04/workplace/lzy/runpl/opt-500
REM CASTEP 18.1 from code version baee3ec33e17+ Mon, 11 Dec 2017 11:05:17 +0000
REM Functional Perdew Burke Ernzerhof Relativity Koelling-Harmon Dispersion off
REM Cut-off 900.0000 eV Grid scale 1.7500 Gmax 26.8966 1/A FBSC none
REM Offset 0.000 0.000 0.000 No. kpts 528 Spacing 0.02
REM
REM buildcell < RbF.cell (41eb211071b3877f8c09973bc960d19d)
REM AIRSS Version 0.9.1 July 2018 build 1bf2d1493bf5+ Mon, 02 Jul 2018 10:54:10 +0100
REM
REM Rb 2|2.1|5|6|7|40U:50:41
REM 
CELL 1.54180    2.33581    2.33578    3.31286   90.00000   90.00000   90.00000
LATT -1
SFAC Rb 
Rb     1  1.0000000000000  0.1217681000000  0.7500000000000 1.0
Rb     1  0.5000000000000  0.6217681000000  0.2500000000000 1.0
END

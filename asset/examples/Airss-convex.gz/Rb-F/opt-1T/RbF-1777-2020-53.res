TITL RbF-1777-2020-53 999.9996 6.503421 -1.26215884E+003 0 0 2 (Immm) n - 1
REM
REM Run started: Tue, 04 Aug 2020 00:57:24 +0800 in /lustre/data/cuit04/lzy/runpl/opt-1T
REM CASTEP 18.1 from code version baee3ec33e17+ Mon, 11 Dec 2017 11:05:17 +0000
REM Functional Perdew Burke Ernzerhof Relativity Koelling-Harmon Dispersion off
REM Cut-off 900.0000 eV Grid scale 1.7500 Gmax 26.8966 1/A FBSC none
REM Offset 0.000 0.000 0.000 No. kpts 11880 Spacing 0.02
REM
REM buildcell < RbF.cell (99440557eaae093f0595f243b74fa7b6)
REM AIRSS Version 0.9.1 July 2018 build 1bf2d1493bf5+ Mon, 02 Jul 2018 10:54:10 +0100
REM
REM F 2|1.2|14|16|18|20:21(qc=7)
REM 
CELL 1.54180    1.62930    1.77501    2.67632   76.06673   72.27840   62.68026
LATT -1
SFAC F  
F      1  0.3529617000000  0.2500001000000  0.7500000000000 1.0
F      1  0.3529617000000  0.7500001000000  0.2500000000000 1.0
END

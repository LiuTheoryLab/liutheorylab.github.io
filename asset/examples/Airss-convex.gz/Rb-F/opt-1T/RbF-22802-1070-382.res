TITL RbF-22802-1070-382 1000.0257 6.503454 -1.26215916E+003 0 0 2 (Immm) n - 1
REM
REM Run started: Fri, 07 Aug 2020 04:14:18 +0800 in /lustre/data/cuit04/lzy/runpl/opt-1T
REM CASTEP 18.1 from code version baee3ec33e17+ Mon, 11 Dec 2017 11:05:17 +0000
REM Functional Perdew Burke Ernzerhof Relativity Koelling-Harmon Dispersion off
REM Cut-off 900.0000 eV Grid scale 1.7500 Gmax 26.8966 1/A FBSC none
REM Offset 0.000 0.000 0.000 No. kpts 12210 Spacing 0.02
REM
REM buildcell < RbF.cell (99440557eaae093f0595f243b74fa7b6)
REM AIRSS Version 0.9.1 July 2018 build 1bf2d1493bf5+ Mon, 02 Jul 2018 10:54:10 +0100
REM
REM F 2|1.2|14|16|18|20:21(qc=7)
REM 
CELL 1.54180    1.62928    1.77505    2.67633   87.79594   72.27871   62.68126
LATT -1
SFAC F  
F      1  0.7678604000000  0.5931880000000  0.3710912000000 1.0
F      1  0.2678604000000  0.0931880000000  0.8710912000000 1.0
END

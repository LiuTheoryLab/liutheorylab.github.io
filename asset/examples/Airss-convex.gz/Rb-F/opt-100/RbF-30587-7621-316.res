TITL RbF-30587-7621-316 99.9405 21.206770 -1.33866870E+003 0 0 2 (Pm-3m) n - 1
REM
REM Run started: Sat, 18 Apr 2020 03:46:32 +0800 in /lustre/data/cuit04/lzy/runpl/opt-100
REM CASTEP 18.1 from code version baee3ec33e17+ Mon, 11 Dec 2017 11:05:17 +0000
REM Functional Perdew Burke Ernzerhof Relativity Koelling-Harmon Dispersion off
REM Cut-off 900.0000 eV Grid scale 1.7500 Gmax 26.8966 1/A FBSC none
REM Offset 0.000 0.000 0.000 No. kpts 550 Spacing 0.02
REM
REM buildcell < RbF.cell (a0aefd309a5afecf8c4503670485945b)
REM AIRSS Version 0.9.1 July 2018 build 1bf2d1493bf5+ Mon, 02 Jul 2018 10:54:10 +0100
REM
REM Rb 2|2.1|5|6|7|40U:50:41
REM F 2|1.2|14|16|18|20:21(qc=7)
REM 
CELL 1.54180    2.76835    2.76775    2.76775   90.00000   90.00000   90.00000
LATT -1
SFAC F  Rb 
F      1  0.5090298860012  0.0000000000000  0.0000000000000 1.0
Rb     2  1.0090298860012  0.5000000000000  0.5000000000000 1.0
END

TITL RbF-29726-9978-1516 99.9958 29.486651 -1.35244292E+003 0 0 2 (P63/mmc) n - 1
REM
REM Run started: Fri, 17 Apr 2020 18:34:16 +0800 in /lustre/data/cuit04/lzy/runpl/opt-100
REM CASTEP 18.1 from code version baee3ec33e17+ Mon, 11 Dec 2017 11:05:17 +0000
REM Functional Perdew Burke Ernzerhof Relativity Koelling-Harmon Dispersion off
REM Cut-off 900.0000 eV Grid scale 1.7500 Gmax 26.8966 1/A FBSC none
REM Offset 0.000 0.000 0.000 No. kpts 1452 Spacing 0.02
REM
REM buildcell < RbF.cell (a0aefd309a5afecf8c4503670485945b)
REM AIRSS Version 0.9.1 July 2018 build 1bf2d1493bf5+ Mon, 02 Jul 2018 10:54:10 +0100
REM
REM Rb 2|2.1|5|6|7|40U:50:41
REM 
CELL 1.54180    2.76627    4.45003    2.76636   90.00024   59.98377   90.00410
LATT -1
SFAC Rb 
Rb     1  0.3333969569020  0.7500000000000  0.8333549722322 1.0
Rb     1  0.6666030430980  0.2500000000000  0.1666450277678 1.0
END
